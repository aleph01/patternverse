import { readFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { Plugin } from 'vite';
import { repertoireCatalog } from './catalog';

/** Read-only local fixture routes. Never part of the public application build. */
export function musicDemoServer(
  repository: string,
  privateMidi?: string,
  privateDirectory = resolve(repository, '.local/music-repertoire'),
): Plugin {
  const files = new Map(
    repertoireCatalog.flatMap((entry) => {
      const path = entry.private
        ? entry.id === 'wonder-superstition-demo' && privateMidi
          ? privateMidi
          : resolve(privateDirectory, entry.file)
        : resolve(repository, 'docs/musical-composition/midi-research', entry.file);
      return path ? [[entry.id, path] as const] : [];
    }),
  );
  return {
    name: 'local-repertoire-midi',
    configureServer(server) {
      server.middlewares.use(async (request, response, next) => {
        const path = new URL(request.url ?? '/', 'http://localhost').pathname;
        if (!path.startsWith('/repertoire/')) return next();
        response.setHeader('Cache-Control', 'no-store');
        if (request.method !== 'GET' && request.method !== 'HEAD') {
          response.statusCode = 405;
          response.setHeader('Allow', 'GET, HEAD');
          return response.end();
        }
        try {
          let body: string | Buffer;
          if (path === '/repertoire/catalog.json') {
            const available = await Promise.all(
              repertoireCatalog.map(async (entry) => {
                const file = files.get(entry.id);
                if (!file) return null;
                const present = await stat(file).catch(() => null);
                return present?.isFile() ? entry : null;
              }),
            );
            body = JSON.stringify(available.filter(Boolean));
            response.setHeader('Content-Type', 'application/json');
          } else {
            const id = /^\/repertoire\/([a-z0-9-]+)\.mid$/.exec(path)?.[1];
            const file = id ? files.get(id) : undefined;
            if (!file) {
              response.statusCode = 404;
              return response.end('MIDI example not found.');
            }
            body = await readFile(file);
            response.setHeader('Content-Type', 'audio/midi');
          }
          response.statusCode = 200;
          response.end(request.method === 'HEAD' ? undefined : body);
        } catch {
          response.statusCode = 503;
          response.end('This local example could not load.');
        }
      });
    },
  };
}
