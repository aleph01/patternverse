import { frequency, type MusicExample, type Note, type Part } from './examples';
import { defaultInstrumentation, instrumentVoice, type Instrumentation } from './instruments';
import { tracksFor } from './model';
import { clockFor } from './timing';
import { preparePiano } from './piano';
import { percussionVoice } from './percussion';
import { claimMusicPlayback, releaseMusicPlayback } from './playback-focus';

export type Playback = { playing: boolean; beat: number };
export type PlaybackOptions = {
  tempo: number;
  loop: boolean;
  parts: Part[];
  volume: number;
  instrumentation: Instrumentation;
};

/** A short look-ahead schedules against the audio clock, not animation frames. */
export function createTransport(example: MusicExample, changed: (state: Playback) => void) {
  let context: AudioContext | undefined;
  let master: GainNode | undefined;
  let options: PlaybackOptions = {
    tempo: example.tempo,
    loop: false,
    parts: tracksFor(example).map((track) => track.id),
    volume: 0.35,
    instrumentation: { ...defaultInstrumentation },
  };
  let playing = false,
    beat = 0,
    anchorBeat = 0,
    anchorTime = 0;
  let generation = 0,
    disposed = false;
  let timer: ReturnType<typeof setInterval> | undefined;
  let cycle = 0,
    index = 0;
  const tracks = tracksFor(example);
  const notes = [...example.notes].sort((a, b) => a.start - b.start);
  let clock = clockFor(example);
  const voices = new Set<{
    oscillator: AudioScheduledSourceNode;
    filter: BiquadFilterNode;
    envelope: GainNode;
  }>();
  const emit = () => changed({ playing, beat });
  const absoluteBeat = () =>
    clock.beat(clock.seconds(anchorBeat) + Math.max(0, (context?.currentTime ?? 0) - anchorTime));
  function silence() {
    for (const voice of voices) {
      voice.oscillator.stop();
      voice.oscillator.disconnect();
      voice.filter.disconnect();
      voice.envelope.disconnect();
    }
    voices.clear();
  }
  function pause() {
    generation += 1;
    if (playing) {
      const absolute = absoluteBeat();
      beat = options.loop ? absolute % example.beats : Math.min(absolute, example.beats);
    }
    playing = false;
    clearInterval(timer);
    silence();
    releaseMusicPlayback(pause);
    emit();
  }
  function tone(note: Note, startBeat: number, duration = note.duration) {
    if (!context || !master || !options.parts.includes(note.part)) return;
    const start = Math.max(
      context.currentTime,
      anchorTime + clock.seconds(startBeat) - clock.seconds(anchorBeat),
    );
    const seconds = clock.seconds(startBeat + duration) - clock.seconds(startBeat);
    const drum = note.drum ?? tracks.find((track) => track.id === note.part)?.drum;
    const level =
      (note.part === 'chords' || note.part === 'accompaniment' ? 0.085 : 0.22) *
      (note.velocity ?? 1);
    const voice = drum
      ? percussionVoice(context, master, drum, start, level)
      : instrumentVoice(
          context,
          master,
          options.instrumentation[note.part] ??
            tracks.find((track) => track.id === note.part)?.instrument ??
            'piano',
          frequency(note.midi),
          start,
          seconds,
          level,
        );
    const { oscillator, filter, envelope } = voice;
    voices.add(voice);
    oscillator.onended = () => {
      voices.delete(voice);
      oscillator.disconnect();
      filter.disconnect();
      envelope.disconnect();
    };
    oscillator.start(start);
    oscillator.stop(start + ('seconds' in voice ? voice.seconds : seconds));
  }
  function tick() {
    if (!playing || !context) return;
    if (context.state !== 'running') {
      pause();
      return;
    }
    const absolute = absoluteBeat();
    beat = options.loop ? absolute % example.beats : Math.min(absolute, example.beats);
    if (!options.loop && absolute >= example.beats) {
      playing = false;
      clearInterval(timer);
      releaseMusicPlayback(pause);
      emit();
      return;
    }
    const horizon = clock.beat(clock.seconds(absolute) + 0.15);
    // Bound each tick even if a tab wakes after a long suspension.
    for (let count = 0; count < 256; count += 1) {
      if (index >= notes.length) {
        if (!options.loop) break;
        index = 0;
        cycle += 1;
      }
      const note = notes[index];
      const start = cycle * example.beats + note.start;
      if (start > horizon) break;
      // Late events are skipped, rather than sounding in a burst after a stalled tab.
      if (start >= absolute - 0.05) tone(note, start);
      index += 1;
    }
    emit();
  }
  async function play() {
    if (disposed || playing) return;
    const token = ++generation;
    claimMusicPlayback(pause);
    try {
      if (!context) {
        context = new AudioContext();
        master = context.createGain();
        master.gain.value = options.volume;
        master.connect(context.destination);
      }
      if (context.state !== 'running') await context.resume();
      if (disposed || token !== generation) return;
      if (context.state !== 'running') throw new Error('Audio is unavailable.');
      await preparePiano(
        context,
        notes
          .filter(
            (note) =>
              options.parts.includes(note.part) &&
              !note.drum &&
              !tracks.find((track) => track.id === note.part)?.drum &&
              (options.instrumentation[note.part] ??
                tracks.find((track) => track.id === note.part)?.instrument ??
                'piano') === 'piano',
          )
          .map((note) => note.midi),
      );
      if (disposed || token !== generation) return;
      if (beat >= example.beats) beat = 0;
      anchorBeat = beat;
      anchorTime = context.currentTime + 0.03;
      cycle = 0;
      index = notes.findIndex((note) => note.start >= beat);
      if (index < 0) index = notes.length;
      for (const note of notes) {
        if (
          !note.drum &&
          !tracks.find((track) => track.id === note.part)?.drum &&
          note.start < beat &&
          note.start + note.duration > beat
        ) {
          tone(note, beat, note.start + note.duration - beat);
        }
      }
      playing = true;
      tick();
      timer = setInterval(tick, 25);
    } catch (error) {
      if (disposed || token !== generation) return;
      pause();
      throw error;
    }
  }
  return {
    play,
    pause,
    async seek(value: number) {
      const resume = playing;
      pause();
      beat = Math.max(0, Math.min(value, example.beats));
      emit();
      if (resume) await play();
    },
    async configure(next: Partial<PlaybackOptions>) {
      const resume = playing;
      const restart =
        next.tempo !== undefined ||
        next.loop !== undefined ||
        next.parts !== undefined ||
        next.instrumentation !== undefined;
      if (restart) pause();
      options = {
        ...options,
        ...next,
        instrumentation: { ...(next.instrumentation ?? options.instrumentation) },
      };
      options.tempo = Math.max(10, Math.min(400, options.tempo));
      clock = clockFor(example, options.tempo);
      options.volume = Math.max(0, Math.min(1, options.volume));
      if (master) master.gain.value = options.volume;
      if (restart && resume) await play();
    },
    dispose() {
      disposed = true;
      pause();
      void context?.close().catch(() => {});
    },
  };
}
