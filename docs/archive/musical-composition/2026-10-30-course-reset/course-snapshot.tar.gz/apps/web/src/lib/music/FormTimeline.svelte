<script lang="ts">
  import type { MusicExample } from './model';
  import { formActivity, formLayers, formSections } from './form';
  let {
    example,
    beat,
    playing,
    onseek,
    disabled = false,
  }: {
    example: MusicExample;
    beat: number;
    playing: boolean;
    onseek: (beat: number) => void;
    disabled?: boolean;
  } = $props();
  const sections = $derived(formSections(example));
  const layers = $derived(formLayers(example));
  const activity = $derived(formActivity(example));
  const maximum = $derived(Math.max(1, ...activity.map((b) => b.count)));
  const minimum = $derived(
    Math.max(400, ...sections.map((s) => (example.beats / (s.end - s.start)) * 110)),
  );
  let scroller = $state<HTMLDivElement>();
  let timeline = $state<HTMLDivElement>();
  const current = $derived(sections.findIndex((s) => beat >= s.start && beat < s.end));
  $effect(() => {
    const index = current;
    if (!playing || index < 0 || !scroller || !timeline) return;
    const node = timeline.querySelectorAll<HTMLElement>('.form-section')[index];
    if (!node) return;
    const bounds = node.getBoundingClientRect(),
      viewport = scroller.getBoundingClientRect();
    if (bounds.left < viewport.left || bounds.right > viewport.right)
      scroller.scrollLeft += bounds.left - viewport.left - 4;
  });
</script>

<!-- svelte-ignore a11y_no_noninteractive_tabindex (The region provides keyboard scrolling on narrow screens.) -->
<div
  class="form-scroll"
  role="region"
  aria-label="Whole-piece timeline"
  tabindex="0"
  bind:this={scroller}
>
  <div class="form-timeline" style={`min-width:${minimum}px`} bind:this={timeline}>
    <div class="section-track">
      {#each sections as section, i (`${section.start}:${i}`)}
        <button
          type="button"
          class="form-section"
          class:current={current === i}
          aria-current={current === i ? 'step' : undefined}
          {disabled}
          style={`left:${(section.start / example.beats) * 100}%;width:${((section.end - section.start) / example.beats) * 100}%`}
          aria-label={`Go to ${section.label}, beat ${section.start + 1}, ${section.end - section.start} beats`}
          onclick={() => onseek(section.start)}
        >
          <strong>{section.label}</strong><span>{section.end - section.start} beats</span>
        </button>
      {/each}
    </div>
    <details class="form-detail">
      <summary>Show layers and activity</summary>
      <p class="detail-help">Bars show when notes sound. Labels identify each part.</p>
      {#each layers as layer (layer.id)}
        <div class="layer-label">{layer.label}</div>
        <div
          class="form-lane"
          aria-label={`${layer.label}: ${layer.spans.length ? `first enters at beat ${layer.spans[0].start + 1}` : 'silent'}`}
        >
          {#each layer.spans as span, i (i)}<span
              class="layer-span"
              style={`left:${(span.start / example.beats) * 100}%;width:${((span.end - span.start) / example.beats) * 100}%`}
            ></span>{/each}
        </div>
      {/each}
      <div class="activity-label">Note onsets per bar · activity, not loudness or emotion</div>
      <svg
        viewBox="0 0 800 90"
        role="img"
        aria-label={`Note onsets in successive bars: ${activity.map((b) => b.count).join(', ')}`}
        preserveAspectRatio="none"
      >
        <title>Note activity across the whole passage</title>
        <polyline
          points={activity
            .map(
              (b) =>
                `${((b.start + (b.end - b.start) / 2) / example.beats) * 800},${80 - (b.count / maximum) * 65}`,
            )
            .join(' ')}
        />
      </svg>
    </details>
    <div
      class="form-playhead"
      aria-hidden="true"
      style={`left:${Math.min(99.8, Math.max(0, (beat / example.beats) * 100))}%`}
    ></div>
  </div>
</div>
<p class="form-help">Width = time across the whole passage. Select a span to listen from there.</p>

<style>
  .form-scroll {
    overflow-x: auto;
    border: 1px solid var(--ink);
  }
  .form-timeline {
    position: relative;
    background: var(--paper);
    color: var(--ink);
  }
  .section-track {
    height: 90px;
    position: relative;
  }
  .form-section {
    box-sizing: border-box;
    position: absolute;
    height: 90px;
    padding: 10px;
    border: 0;
    border-right: 1px solid color-mix(in srgb, var(--ink) 25%, transparent);
    border-top: 3px solid var(--green-dark);
    background: color-mix(in srgb, var(--green-dark) 8%, var(--paper));
    color: var(--ink);
    font: inherit;
    text-align: left;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  .form-section strong {
    font-size: 0.85rem;
    line-height: 1.2;
  }
  .form-section span {
    font-size: 0.65rem;
  }
  .form-section.current {
    box-shadow: inset 0 0 0 2px var(--ink);
    background: color-mix(in srgb, var(--green-dark) 20%, var(--paper));
  }
  .form-section:focus-visible {
    outline: 3px solid var(--focus-color);
    outline-offset: -4px;
  }
  summary {
    cursor: pointer;
    padding: 12px;
    min-height: 44px;
    box-sizing: border-box;
    border-top: 1px solid color-mix(in srgb, var(--ink) 25%, transparent);
    font-size: 0.75rem;
  }
  .detail-help,
  .form-help {
    font-size: 0.68rem;
    line-height: 1.5;
    color: var(--muted);
    margin: 10px 12px;
  }
  .form-help {
    margin: 8px 0;
  }
  .layer-label,
  .activity-label {
    font-size: 0.68rem;
    padding: 7px 10px;
  }
  .form-lane {
    height: 22px;
    position: relative;
    background: color-mix(in srgb, var(--ink) 5%, var(--paper));
  }
  .layer-span {
    position: absolute;
    inset-block: 4px;
    min-width: 1px;
    background: var(--green-dark);
  }
  .activity-label {
    margin-top: 8px;
  }
  svg {
    width: 100%;
    height: 90px;
    display: block;
  }
  polyline {
    fill: none;
    stroke: var(--ink);
    stroke-width: 2;
    vector-effect: non-scaling-stroke;
  }
  .form-playhead {
    position: absolute;
    inset-block: 0;
    width: 2px;
    pointer-events: none;
    background: var(--ink);
  }
</style>
