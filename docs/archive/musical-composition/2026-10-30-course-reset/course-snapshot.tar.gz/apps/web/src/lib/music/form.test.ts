import { describe, expect, it } from 'vitest';
import { formExample, layeredEntrances } from './form-examples';
import { formActivity, formLayers, formSections } from './form';
import { withVariant } from './model';
import { exampleForChapter } from './examples';

describe('whole-piece form and controlled layered entry', () => {
  it('changes only the entrance schedule, with an identical reference and subsequent notes', () => {
    const a = withVariant(formExample, 'a'),
      b = withVariant(formExample, 'b');
    expect(a.notes.filter((n) => n.part === 'figure')).toEqual(
      b.notes.filter((n) => n.part === 'figure'),
    );
    for (const [part, entrance] of Object.entries(layeredEntrances)) {
      const notes = b.notes.filter((n) => n.part === part);
      expect(notes[0].start).toBe(entrance);
      expect(notes).toEqual(a.notes.filter((n) => n.part === part && n.start >= entrance));
    }
    expect([a.tempo, a.beatsPerBar, a.beats, a.tracks]).toEqual([
      b.tempo,
      b.beatsPerBar,
      b.beats,
      b.tracks,
    ]);
    expect(formExample.notes).toEqual(b.notes);
    expect(a.notes.every((n) => n.start >= 0 && n.start + n.duration <= a.beats)).toBe(true);
  });
  it('uses full-passage section coordinates and independent variant labels', () => {
    const a = withVariant(formExample, 'a'),
      b = withVariant(formExample, 'b');
    expect(formSections(b).map((s) => [s.start, s.end])).toEqual([
      [0, 8],
      [8, 16],
      [16, 24],
      [24, 32],
    ]);
    expect(formSections(a)[0].label).toBe('Full texture');
    expect(formSections(b)[0].label).toBe('Figure');
    expect(formSections(b).at(-1)?.end).toBe(b.beats);
    expect(exampleForChapter('songwriting-choose-a-song-form')).toBe(formExample.id);
    expect(exampleForChapter('songwriting-shape-energy-over-time')).toBe(formExample.id);
  });
  it('preserves unequal lengths, clips invalid boundaries, and leaves unannotated examples alone', () => {
    const sections = formSections({
      ...formExample,
      sections: [
        { label: 'B', start: 2, end: 8 },
        { label: 'A', start: -2, end: 2 },
        { label: 'C', start: 8, end: 50 },
        { label: 'Empty', start: 4, end: 4 },
        { label: 'Invalid', start: NaN, end: 7 },
      ],
    });
    expect(sections.map((s) => s.end - s.start)).toEqual([2, 6, 24]);
    expect(formSections({ ...formExample, sections: undefined })).toEqual([]);
  });
  it('merges overlapping sounding notes without filling actual rests', () => {
    const layers = formLayers(formExample);
    expect(layers.find((l) => l.id === 'sustain')?.spans).toEqual([{ start: 16, end: 32 }]);
    expect(layers.find((l) => l.id === 'low')?.spans.slice(0, 2)).toEqual([
      { start: 8, end: 9.8 },
      { start: 10, end: 11.8 },
    ]);
  });
  it('counts authored note onsets, without pretending to measure perceived intensity', () => {
    expect(formActivity(withVariant(formExample, 'a')).map((b) => b.count)).toEqual(
      Array(8).fill(16),
    );
    expect(formActivity(formExample).map((b) => b.count)).toEqual([4, 4, 6, 6, 8, 8, 16, 16]);
    expect(formActivity({ ...formExample, notes: [] }).map((b) => b.count)).toEqual(
      Array(8).fill(0),
    );
  });
});
