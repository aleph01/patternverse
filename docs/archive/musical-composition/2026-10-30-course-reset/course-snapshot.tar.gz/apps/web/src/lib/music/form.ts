import { tracksFor, type MusicExample } from './model';
import { measuresFor } from './timing';

/** Use the transport's quarter-note coordinates for the complete passage, independent of paging. */
export function formSections(example: MusicExample) {
  return (example.sections ?? [])
    .filter((s) => Number.isFinite(s.start) && Number.isFinite(s.end))
    .map((s) => ({ ...s, start: Math.max(0, s.start), end: Math.min(example.beats, s.end) }))
    .filter((s) => s.start < s.end)
    .sort((a, b) => a.start - b.start);
}

export function formLayers(example: MusicExample) {
  return tracksFor(example).map((track) => {
    const notes = example.notes
      .filter((n) => n.part === track.id && n.duration > 0)
      .map((n) => ({
        start: Math.max(0, n.start),
        end: Math.min(example.beats, n.start + n.duration),
      }))
      .filter((n) => n.start < n.end)
      .sort((a, b) => a.start - b.start);
    const spans: { start: number; end: number }[] = [];
    for (const note of notes) {
      const last = spans.at(-1);
      if (last && note.start <= last.end + 1e-7) last.end = Math.max(last.end, note.end);
      else spans.push({ ...note });
    }
    return { ...track, spans };
  });
}

/** Observable note activity, deliberately not a loudness, intensity or emotion estimate. */
export function formActivity(example: MusicExample) {
  return measuresFor(example).map((bar) => ({
    ...bar,
    count: example.notes.filter((n) => n.start >= bar.start && n.start < bar.end).length,
  }));
}
