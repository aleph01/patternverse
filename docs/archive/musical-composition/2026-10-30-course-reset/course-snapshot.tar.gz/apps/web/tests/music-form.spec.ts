import { expect, test } from '@playwright/test';

const playerFor = (page: import('@playwright/test').Page) =>
  page.getByRole('region', { name: 'Musical example player', exact: true });
test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Pattern comparisons (5)', exact: true }).click();
  await playerFor(page)
    .getByLabel('Musical example', { exact: true })
    .selectOption('form-layered-entry');
});

test('starts with a simple whole-piece map, reveals layers, and seeks the matching piano-roll window', async ({
  page,
}, info) => {
  const player = playerFor(page);
  if (info.project.name === 'phone') await page.setViewportSize({ width: 320, height: 850 });
  await expect(player.getByRole('button', { name: 'Structure', exact: true })).toHaveAttribute(
    'aria-pressed',
    'true',
  );
  await expect(player.locator('.description')).toContainText(
    'Form is how a piece unfolds through time.',
  );
  await expect(player.locator('.note-grid')).toHaveCount(0);
  await expect(player.locator('.form-detail')).not.toHaveAttribute('open');
  await expect(player.locator('.form-section')).toHaveCount(4);
  const stage = player.locator('.form-section').nth(2);
  await stage.focus();
  await stage.press('Enter');
  await expect(player.locator('.position')).toHaveText('Bar 5 · beat 1.0');
  await expect(stage).toHaveAttribute('aria-current', 'step');
  await player.getByRole('button', { name: 'Piano roll', exact: true }).click();
  await expect(player.locator('.bar-labels span').first()).toHaveText('Bar 5');
  await player.getByRole('button', { name: 'Structure', exact: true }).click();
  const disclosure = player.getByText('Show layers and activity', { exact: true });
  if (info.project.name === 'phone') await disclosure.tap();
  else await disclosure.click();
  await expect(player.locator('.form-lane')).toHaveCount(4);
  await expect(player.locator('.form-lane').nth(1)).toHaveAttribute(
    'aria-label',
    'Bass: first enters at beat 9',
  );
  await expect(
    player.getByRole('img', { name: 'Note onsets in successive bars: 4, 4, 6, 6, 8, 8, 16, 16' }),
  ).toBeVisible();
  await player.getByText('What changes in A/B?', { exact: true }).click();
  await expect(player.locator('.comparison-notes')).toContainText('What stayed the same?');
  await expect(player.locator('.comparison-notes')).toContainText('When would I use it?');
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await player.screenshot({ path: test.info().outputPath(`form-${info.project.name}.png`) });
});

test('keeps the whole-piece clock across A/B, navigation, views and looping', async ({ page }) => {
  const player = playerFor(page);
  await player.getByLabel('Loop', { exact: true }).check();
  await player.locator('.form-section').last().click();
  await player.getByRole('button', { name: 'Play', exact: true }).click();
  await expect(player.locator('.position')).toHaveAttribute('data-playback', 'playing');
  await expect(player.locator('.form-section').last()).toHaveAttribute('aria-current', 'step');
  await player.getByRole('button', { name: 'A Constant texture', exact: true }).click();
  await expect(player.locator('.position')).toHaveAttribute('data-playback', 'playing');
  await expect(player.locator('.form-section').first()).toContainText('Full texture');
  await player.getByRole('button', { name: 'B Layered entry', exact: true }).click();
  await expect(player.locator('.position')).toHaveAttribute('data-playback', 'playing');
  await expect(player.locator('.form-section').first()).toHaveAttribute('aria-current', 'step', {
    timeout: 9000,
  });
  await player.getByRole('button', { name: 'Piano roll', exact: true }).click();
  await expect(player.locator('.note.sounding')).not.toHaveCount(0);
  await player.getByRole('button', { name: 'Pause', exact: true }).click();
  await player.getByRole('button', { name: 'Structure', exact: true }).click();
  await expect(player.locator('.form-playhead')).toBeVisible();
});
